<?php

class News_m extends Trix_Model {
}