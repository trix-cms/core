<?php $this->template->begin_content()?>
    <div class="page-header">
        <h2>
            Новости
        </h2>
    </div>
    
    <?=$content?>
<?php $this->template->end_content()?>