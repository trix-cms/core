<?php

namespace News;

class Config {
    
    static $upload_folder = 'uploads/news/';
}