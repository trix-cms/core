<?php

$config['news_admin_news_per_page'] = 10;
