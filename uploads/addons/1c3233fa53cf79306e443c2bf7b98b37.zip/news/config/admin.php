<?php

$config['wysiwyg_actions'] = array('add', 'edit');