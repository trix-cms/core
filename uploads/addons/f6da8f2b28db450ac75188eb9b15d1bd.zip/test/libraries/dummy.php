<?php

namespace Test;

class Dummy
{
    function run()
    {
        echo '123';
    }
}